package com.jsoniter.demo;

import java.nio.charset.UnsupportedCharsetException;

import com.jsoniter.JsonIterator;
import com.jsoniter.any.Any;
import com.jsoniter.output.EncodingMode;
import com.jsoniter.output.JsonStream;
import com.jsoniter.spi.DecodingMode;

public class Demo {
    static {
        // ensure the jsoniter is properly setup
        new DemoCodegenConfig().setup();
    }

    public static void main(String[] args) {
        Usuario usuario = JsonIterator.deserialize("{\"firstName\": \"tao\", \"lastName\": \"wen\", \"score\": \"1024\"}", Usuario.class);
        System.out.println(usuario.apellido1);
        System.out.println(usuario.apellido2);
        System.out.println(usuario.puntuacion);
        usuario.attach = Any.wrapArray(new int[]{1, 2, 3});
        System.out.println(JsonStream.serialize(usuario));
    }
}
