import com.jsoniter.annotation.JsonProperty;
import com.jsoniter.any.Any;

public class Usuario {
    @JsonProperty(nullable = false)
    public String apellido1;
    @JsonProperty(nullable = false)
    public String apellido2;
    public int puntuacion;
    public Any attach;
}

