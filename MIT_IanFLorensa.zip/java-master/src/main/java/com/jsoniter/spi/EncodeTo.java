package com.jsoniter.spi;

public class EncodeTo {
    public Binding binding;
    public String toName;
}
