package com.jsoniter;

public class User {
    public int userId;
    public String name;
    public String[] tags;
}
