package com.jsoniter;

import com.jsoniter.any.Any;

import java.util.List;

public class ComplexObject {
    public int field1;
    public List<List<Integer>> field2;
    public Any field3;
}
