[![Build Status](https://travis-ci.org/json-iterator/java.svg?branch=master)](https://travis-ci.org/json-iterator/java)
[![codecov](https://codecov.io/gh/json-iterator/java/branch/master/graph/badge.svg)](https://codecov.io/gh/json-iterator/java)
[![License](http://img.shields.io/badge/license-mit-blue.svg?style=flat-square)](https://raw.githubusercontent.com/json-iterator/java/master/LICENSE)
[![Gitter chat](https://badges.gitter.im/gitterHQ/gitter.png)](https://gitter.im/json-iterator/Lobby)

Documentation : [http://jsoniter.com/java-features.html](http://jsoniter.com/java-features.html)

Scala User: https://github.com/plokhotnyuk/jsoniter-scala